import javax.swing.*;
import java.awt.*;

public class MyFrameC extends MyFrameA{
	
	public MyFrameC (String title, int quad, int begin, int end, int steps) {
		setTitle(title);

		//setSize bekommt zweimal den Wert quad übergeben, JFrame wird so quadratisch
        setSize(quad, quad);
        setLayout(new FlowLayout(FlowLayout.LEADING));
        showNumbers(begin, end, steps);
        setVisible(true);
	}

	public void showNumbers(int von, int bis, int schritte){
	    /*
	    Die Funktion, die eine beliebige Anzahl an Nummern anzeigen soll, bekommt einen Anfangswert und einen Endwert
	    als Parameter übergeben und zusätzlich einen Schrittzähler, also in welchen Schritten gezählt wird.
        */
	    int i;
	    String str;

	    if (von <= bis){
	        // Die if-Verzweigung klärt, ob von unten nach oben oder anders herum gezählt wird

            for (i = von; i <= bis; i += schritte) {

                /*
                i wird dabei immer in einen String umgewandelt und kann dann als Parameter an das Objekt JLabel
                übergeben werden, welches so jedes i im JFrame darstellt
                */
                str = String.valueOf(i);

                add(new JLabel(str));
            }
        } else {
            for (i = von; i >= bis; i -= schritte) {

                str = String.valueOf(i);

                add(new JLabel(str));
            }
        }
    }

}
