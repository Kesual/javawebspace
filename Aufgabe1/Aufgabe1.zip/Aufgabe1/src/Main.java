
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new MyFrameA(1111, 200, 200);

        new MyFrameB(2013, 200, 200,  3);

		new MyFrameC("Zahlen", 300, 2, 100, 2);
	}

}
