import javax.swing.JFrame;

public class MyFrameA extends JFrame {
	
	public MyFrameA (int title) {
		setTitle(title);

		/*
		* Automatisches setzen der Größe, falls nicht der Konstruktor genommen wird, in dem selbst die größe gesetz wird
		* Siehe auch MyFrameB
		*/

		setSize(200, 200);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public MyFrameA (int title, int width, int height) {
		setTitle(title);
		setSize(width, height);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}


	public MyFrameA(){
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

	private void setTitle(int title) {

		/*
	    Die Standardfunktion setTitle() von JFrame wird von MyFrameA so überschrieben, dass als Parameter ein
	    Integer-Wert übergeben werden muss. Dieser Wert wird durch String.valueOf in einen String umgewandelt, welcher
	    dann an die eigentliche setTitle() Funktion übergeben werden kann.
		 */

		String aTitle = String.valueOf(title);
		setTitle(aTitle);
	}
}
